import UIKit

//a closure that multiplies any two given numbers
var multiplication = { (number1: Float, number2: Float) -> Float in
    return Float(number1 * number2)
}

//assigning values to number1 and number2
let product = multiplication(239.8, 324.123)

//prints the result
print(product)
